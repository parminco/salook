<div id="wrapper">
    <div class="content">
        <section class="gray-bg no-top-padding-sec" id="sec1">

            <div class="container">
                <div style="text-align: center;">
                    <div class="col-md-6" style="padding-top: 70px;float:none;margin: 0 auto">
                        <fieldset class="fl-wrap" style=" position: relative;">
                            <div class="list-single-main-item-title fl-wrap">
                                <h3>خطا در پرداخت</h3>
                            </div>
                            <div class="success-table-container">
                                <div class="success-table-header fl-wrap">
                                    <i class="fal fa-times-circle decsth" style="color: red"></i>
                                    <h4><?= $data['Error'] ?></h4>
                                    <div class="clearfix"></div>
                                    <p>لطفا دوباره فرایند پرداخت رو انجام بدهید.</p>
                                </div>
                            </div>
                            <span class="fw-separator"></span>
                            <a href="index" class="previous-form action-button  color2-bg">بازگشت</a>
                        </fieldset>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
