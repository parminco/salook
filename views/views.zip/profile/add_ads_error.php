<?php
$active = 'ads_insert';
require ('header_profile.php');
?>
<!--  section  end-->
<!--  section  -->
<section class="gray-bg main-dashboard-sec" id="sec1">
    <div class="container">
        <!--  dashboard-menu-->
        <?php require('menu.php'); ?>

        <!-- dashboard-menu  end-->
        <!-- dashboard content-->
        <div class="col-md-9">

            <div class="list-single-main-item fl-wrap block_box" style="min-height: 120px;text-align: center;padding: 50px">
                <h3 style="color: #d4576c">شما مجاز به ثبت تبلیغ نیستید</h3>
                <p style="text-align: center">نمیتوانید بیشتر از حد مجاز تبلیغ ثبت کنید </p>
            </div>

        </div>
</section>
<!--  section  end-->
<div class="limit-box fl-wrap"></div>
</div>
<!--content end-->
</div>

<script src="public/js/dashboard.js"></script>



