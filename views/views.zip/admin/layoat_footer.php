<!-- Begin Page Footer-->
<footer class="main-footer">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-start justify-content-lg-start justify-content-md-start justify-content-center">
            <p class="text-gradient-02">طراحی شده در |  شرکت پارمین وب</p>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-end justify-content-lg-end justify-content-md-end justify-content-center">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link">مستندات</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link">آپدیت ها</a>
                </li>
            </ul>
        </div>
    </div>
</footer>
<!-- End Page Footer -->
<a href="#" class="go-top"><i class="la la-arrow-up"></i></a>

</div>
</div>
<!-- End Page Content -->
</div>
<!-- Begin Vendor Js -->
<script src="public/admin/assets/vendors/js/base/jquery.min.js"></script>
<script src="public/admin/assets/vendors/js/base/core.min.js"></script>
<!-- End Vendor Js -->
<!-- Begin Page Vendor Js -->
<script src="public/admin/assets/vendors/js/nicescroll/nicescroll.min.js"></script>
<script src="public/admin/assets/vendors/js/app/app.min.js"></script>
<script src="public/admin/assets/js/components/validation/validation.min.js"></script>




<script src="public/js/admin_script.js"></script>



<!-- End Page Vendor Js -->
</body>
</html>