<div class="row">
    <div class="container">
        <div class="col-12 default no-padding">
            <div class="product-tabs default">
                <div class="box-tabs default">
                    <div class="card-body default">
                        <div class="tab-pane fade active show" id="comments" role="tabpanel" aria-expanded="false">
                            <article>
                                <img src="public/images/404/404.png" width="500">
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>