<div class="box-widget-item fl-wrap block_box lws_mobile">
    <div class="box-widget-item-header">
        <h3>جستجوی محصولات</h3>
    </div>
    <div class="box-widget fl-wrap">
        <div class="box-widget-content">
            <div class="search-widget">
                <form action="#" class="fl-wrap">
                    <input name="se" id="se" type="text" class="search"
                           placeholder="جستجو ..." value="">
                    <button class="search-submit color2-bg" id="submit_btn"><i
                            class="fal fa-search"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>